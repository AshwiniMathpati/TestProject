package Tweet;

import static io.restassured.RestAssured.given;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Create {
	
	Properties prop;
	Logger l=Logger.getLogger("Create");
	
	   @Test
	 public void Createtweet() throws Exception {
		   
		 prop = new Properties();
		 PropertyConfigurator.configure("C:\\Users\\Online Test\\git\\TestProject\\TwitterApi\\Log4j.properties");
	     FileInputStream fis = new FileInputStream("C:\\Users\\Online Test\\git\\TestProject\\TwitterApi\\src\\data.properties");
	     prop.load(fis);
	    RestAssured.baseURI="https://api.twitter.com/1.1/statuses/";
		Response res = given().auth().oauth(prop.getProperty("consumerkey"),prop.getProperty("consumerSecret"),prop.getProperty("Token"),prop.getProperty("TokenSecret")).
		queryParam("status"," I    am    learning API testing   using RestAssured    #Qualitest")
		.when().post("/update.json").then().extract().response();
				
		String response=res.asString();                 
		//System.out.println(response);
		JsonPath js=new JsonPath(response); 
		l.info(response);
		String id=js.get("id").toString();
		l.info(id);
		System.out.println(id);
		String text=js.get("text").toString();
		l.info(text);
		System.out.println(text);
				
				
	}

}