package Tweet;
import static io.restassured.RestAssured.given;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

 
public class Listoftweets {

 Properties prop;
 Logger l=Logger.getLogger("Listoftweets");

 @Test
    public void ListTweet() throws IOException
    {
        operation p = new operation();
        prop = new Properties();
        PropertyConfigurator.configure("C:\\Users\\Online Test\\git\\TestProject\\TwitterApi\\Log4j.properties");
        FileInputStream fis = new FileInputStream("C:\\Users\\Online Test\\git\\TestProject\\TwitterApi\\src\\data.properties");
        prop.load(fis);
        
        RestAssured.baseURI = "https://api.twitter.com/1.1/statuses";
        Response res = given().auth().oauth(prop.getProperty("consumerkey"),prop.getProperty("consumerSecret"),prop.getProperty("Token"),prop.getProperty("TokenSecret")).
        param("screen_name",p.getUsers()).
        when().
        get("/user_timeline.json").
        then().assertThat().statusCode(200).and().contentType(ContentType.JSON).
        extract().response();
        
        l.info(p.getUsers());
        String response = res.asString();
        //System.out.println(response);

 

        JsonPath js = new JsonPath(response);
         String Text = js.get("text").toString();
        System.out.println(Text);
        
    }
}