package Tweet;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import io.restassured.path.json.JsonPath;

public class weatherbangalore {
	

	Properties prop;
	Logger l=Logger.getLogger("weatherbangalore");
	
	@Test
    public void Bengaluru() throws IOException
    {
		 prop = new Properties();
		 PropertyConfigurator.configure("C:\\Users\\Online Test\\git\\TestProject\\TwitterApi\\Log4j.properties");
	     FileInputStream fis = new FileInputStream("C:\\Users\\Online Test\\git\\TestProject\\TwitterApi\\src\\data.properties");
	     prop.load(fis);
    RestAssured.baseURI = "https://api.twitter.com/1.1/search";
    Response res = given().auth().oauth(prop.getProperty("consumerkey"),prop.getProperty("consumerSecret"),prop.getProperty("Token"),prop.getProperty("TokenSecret")).
    param("q","weather.Banglore").
    when().get("/tweets.json").
    then().assertThat().statusCode(200).and().contentType(ContentType.JSON).
    extract().response();
   
    String response = res.asString();
    l.info(response);
    
    JsonPath js = new JsonPath(response);
    int count = js.get("statuses.size()");
    //System.out.println(count);
   
    String resp;
    for(int i=0;i<count;i++)
    {
    	 String place = js.get("statuses["+i+"].user.location").toString();
         if(place.contains("Bengaluru")||place.contains("Bangalore"))
         {
             resp = js.get("statuses["+i+"]").toString();
             l.info(resp);
    
    }
    }
    }
}






